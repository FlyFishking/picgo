#!/bin/bash

set -e

DIR="$(pwd)"
cd $DIR
source $DIR/common.sh

set +o noglob

usage=$'Please set hostname and other necessary attributes in harbor.yml first. DO NOT use localhost or 127.0.0.1 for hostname, because Harbor needs to be accessed by external clients.
Please set --with-notary if needs enable Notary in Harbor, and set ui_url_protocol/ssl_cert/ssl_cert_key in harbor.yml bacause notary must run under https.
Please set --with-trivy if needs enable Trivy in Harbor
Please set --with-chartmuseum if needs enable Chartmuseum in Harbor'
item=0

# notary is not enabled by default
with_notary=$false
# clair is deprecated
with_clair=$false
# trivy is not enabled by default
with_trivy=$false
# chartmuseum is not enabled by default
with_chartmuseum=$false

while [ $# -gt 0 ]; do
    case $1 in
    --help)
        note "$usage"
        exit 0
        ;;
    --with-notary)
        with_notary=true
        ;;
    --with-clair)
        with_clair=true
        ;;
    --with-trivy)
        with_trivy=true
        ;;
    --with-chartmuseum)
        with_chartmuseum=true
        ;;
    *)
        note "$usage"
        exit 1
        ;;
    esac
    shift || true
done

if [ $with_clair ]; then
    error "Clair is deprecated please remove it from installation arguments !!!"
    exit 1
fi

h2 "[Step $item]: checking if docker is installed ..."
let item+=1
check_docker

h2 "[Step $item]: checking docker-compose is installed ..."
let item+=1
check_dockercompose

if [ -f harbor*.tar.gz ]; then
    h2 "[Step $item]: loading Harbor images ..."
    let item+=1
    docker load -i ./harbor*.tar.gz
fi
echo ""

h2 "[Step $item]: preparing environment ..."
let item+=1
if [ -n "$host" ]; then
    sed "s/^hostname: .*/hostname: $host/g" -i ./harbor.yml
fi

h2 "[Step $item]: preparing harbor configs ..."
let item+=1
prepare_para=
if [ $with_notary ]; then
    prepare_para="${prepare_para} --with-notary"
fi
if [ $with_trivy ]; then
    prepare_para="${prepare_para} --with-trivy"
fi
if [ $with_chartmuseum ]; then
    prepare_para="${prepare_para} --with-chartmuseum"
fi

cp -f ./docker-compose-tmp.yml ./docker-compose.yml
cp -f ./prepare-tmp ./prepare
if [ $(go env GOHOSTARCH) == "arm64" ]; then

    h2 "[Step $item]: gen yaml"
    gsed "s|goharbor|acejilam|g" -i ./prepare || sed "s|goharbor|acejilam|g" -i ./prepare
    gsed "s|v2.6.0|dev|g" -i ./prepare || sed "s|v2.6.0|dev|g" -i ./prepare

fi

./prepare $prepare_para

if [ $(go env GOHOSTARCH) == "arm64" ]; then

    h2 "[Step $item]: gen yaml"
    gsed "s|goharbor|acejilam|g" -i ./docker-compose.yml || sed "s|goharbor|acejilam|g" -i ./docker-compose.yml
    gsed "s|v2.6.0|dev|g" -i ./docker-compose.yml || sed "s|v2.6.0|dev|g" -i ./docker-compose.yml

fi

echo ""

if [ -n "$(docker-compose ps -q)" ]; then
    note "stopping existing Harbor instance ..."
    docker-compose down -v
fi
echo ""

h2 "[Step $item]: starting Harbor ..."

docker-compose up -d

success $"----Harbor has been installed and started successfully.----"
