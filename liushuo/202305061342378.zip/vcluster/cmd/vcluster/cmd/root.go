package cmd

import (
	"github.com/spf13/cobra"
	"os"
)

// NewRootCmd returns a new root command
func NewRootCmd() *cobra.Command {
	return &cobra.Command{
		Use:           "vcluster",
		SilenceUsage:  true,
		SilenceErrors: true,
		Short:         "Welcome to vcluster!",
		Long:          `vcluster root command`,
	}
}

// BuildRoot creates a new root command from the
func BuildRoot() *cobra.Command {
	os.Setenv("NAMESPACE", "vcluster")
	os.Args = append(os.Args, []string{
		"start",
		"--name=vcluster",
		"--request-header-ca-cert=./pki/ca.crt",
		"--client-ca-cert=./pki/ca.crt",
		"--server-ca-cert=./pki/ca.crt",
		"--server-ca-key=./pki/ca.key",
		"--service-account=vc-workload-vcluster",
		"--kube-config-context-name=my-vcluster",
		"--leader-elect=false",
		"--sync=-ingressclasses",
	}...)

	rootCmd := NewRootCmd()

	// add top level commands
	rootCmd.AddCommand(NewStartCommand())
	rootCmd.AddCommand(NewCertsCommand())
	rootCmd.AddCommand(NewHostpathMapperCommand())
	return rootCmd
}
