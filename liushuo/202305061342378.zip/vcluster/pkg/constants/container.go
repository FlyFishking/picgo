package constants

const (
	ContainerManifestsFolder = "/manifests"
)
