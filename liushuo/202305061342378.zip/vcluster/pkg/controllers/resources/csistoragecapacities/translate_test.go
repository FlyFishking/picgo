package csistoragecapacities

// ensure translation matches storageclass translating
