package main

import (
	_ "github.com/apache/skywalking-go"
	"go.uber.org/zap"
	"net/http"
	"time"
)

func main() {
	logger, _ := zap.NewProduction()

	http.HandleFunc("/", func(writer http.ResponseWriter, request *http.Request) {
		logger.Info("failed to fetch URL",
			// Structured context as strongly typed Field values.
			zap.String("url", "/"),
			zap.Int("attempt", 3),
			zap.String("time", time.Now().String()),
			zap.Duration("backoff", time.Second),
		)
		go func() {
			time.Sleep(time.Second * 5)
			resp, err := http.Get("https://baidu.com")
			logger.Info("sleep 5",
				// Structured context as strongly typed Field values.
				zap.String("url", "/"),
				zap.Int("code", resp.StatusCode),
				zap.Error(err),
				zap.Error(err),
				zap.String("time", time.Now().String()),
				zap.Duration("backoff", time.Second),
			)
		}()
		writer.Write([]byte(time.Now().String()))
	})
	http.ListenAndServe(":8080", nil)
}

// docker build -t registry.cn-hangzhou.aliyuncs.com/acejilam/test:sky-go .
// docker push registry.cn-hangzhou.aliyuncs.com/acejilam/test:sky-go
