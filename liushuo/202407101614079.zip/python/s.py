import time

from flask import Flask
from skywalking import agent, config

app = Flask(__name__)


@app.route('/')
def index():
    return str(time.time())


# 导入skywalking python
config.init(agent_name='python-test')
config.flask_collect_http_params = True
# 排除一些不想纳入跟踪的组件
# config.disable_plugins = ['sw_http_server', 'sw_urllib_request','sw_django','sw_tornado','sw_urllib3','sw_sanic','sw_aiohttp','sw_pyramid']
agent.start()

if __name__ == '__main__':
    app.run(port=8002, host='0.0.0.0', debug=True)
